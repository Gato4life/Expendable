EXPENDABLE — Prototype 0.1

HOW TO PLAY
1. Unzip the folder if you downloaded the ZIP.
2. Open index.html in a modern desktop browser (Chrome, Edge, or Firefox recommended).
3. Click ENTER FACILITY.
4. Controls:
   - W / A / S / D: move
   - Mouse: look around (drag to look in browsers without pointer lock)
   - Click/tap: fire
   - Shift: sprint
   - Space: dash
   - R: restart the encounter
   - Escape: release mouse capture

WHAT THIS PROTOTYPE HAS
- Retro raycasted corridors
- Mouse-look and collision
- Sprinting and dashing
- Four basic hostiles that approach the player
- Simple hitscan shooting and health
- A minimap and HUD

KNOWN LIMITATIONS
This is an early prototype. It uses simple placeholder enemies and a placeholder weapon, has no sound yet, and is designed primarily for desktop keyboard/mouse, with tap-to-fire and drag-to-look support on touchscreens. It is a single HTML file; no install or internet connection is required.
