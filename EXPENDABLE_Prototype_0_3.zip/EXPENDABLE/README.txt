EXPENDABLE — Prototype 0.3

HOW TO RUN
Open index.html in a modern browser. GitHub Pages can host this file directly.

CONTROLS
WASD: move
Mouse: look (increased sensitivity)
Click: fire current weapon
1: rifle
2: SPAS-12-inspired pump shotgun (24 shells; five-pellet spread)
M: melee bash with the equipped gun
Shift: sprint
Space: dash
R: restart
Escape: release mouse pointer lock

THIS BUILD
- Four hostile variants maximum in the level: Grunt, Stalker, Crawler, Brute.
- Distinct pixel-art silhouettes, eye colors, health and movement speeds.
- Shotgun secondary with limited ammunition and a separate weapon silhouette.
- Melee bash with the equipped weapon.
- Increased mouse-look sensitivity.

This is a small canvas-based prototype. Enemy visuals are intentionally pixelated and Doom-inspired.
